import pyfiglet
from colorama import Fore, Style

M = Fore.LIGHTMAGENTA_EX+Style.BRIGHT

line = """ \n                       Version script: 4.0.2 """

teg = M+pyfiglet.figlet_format("CalBot",font="5lineoblique")

ColorLine = ("-"*25)
